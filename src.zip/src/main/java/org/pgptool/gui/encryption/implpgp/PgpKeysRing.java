
package org.pgptool.gui.encryption.implpgp;

import java.util.ArrayList;

import org.pgptool.gui.encryption.api.dto.Key;

public class PgpKeysRing extends ArrayList<Key<KeyDataPgp>> {
	private static final long serialVersionUID = -227126239011425515L;

}
