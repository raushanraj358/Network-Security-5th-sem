package org.pgptool.gui.tempfolderfordecrypted.api;

import org.summerb.approaches.validation.FieldValidationException;


public interface DecryptedTempFolder {
	String getTempFolderBasePath();

	void setTempFolderBasePath(String newValue) throws FieldValidationException;
}
