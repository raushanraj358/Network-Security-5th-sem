
package org.pgptool.gui.config.api;

public interface ConfigsBasePathResolver {
	String getConfigsBasePath();
}
