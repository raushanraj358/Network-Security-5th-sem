
package org.pgptool.gui.ui.about;

public interface AboutHost {
	void handleClose();
}
