
package org.pgptool.gui.ui.importkey;

public interface KeyImporterHost {
	void handleImporterFinished();
}
