
package org.pgptool.gui.app;

public enum MessageSeverity {
	ERROR, WARNING, INFO
}
