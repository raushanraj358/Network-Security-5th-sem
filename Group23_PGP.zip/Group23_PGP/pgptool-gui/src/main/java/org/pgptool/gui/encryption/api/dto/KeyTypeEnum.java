
package org.pgptool.gui.encryption.api.dto;

public enum KeyTypeEnum {
	KeyPair, Public;
}
