package org.pgptool.gui.ui.encryptone;

import javax.swing.Action;

public interface EncryptOneHost {
	void handleClose();

	Action getActionToOpenCertificatesList();
}
