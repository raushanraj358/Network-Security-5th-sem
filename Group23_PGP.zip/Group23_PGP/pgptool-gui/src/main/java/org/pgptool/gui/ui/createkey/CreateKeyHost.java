
package org.pgptool.gui.ui.createkey;

public interface CreateKeyHost {
	void handleClose();
}
