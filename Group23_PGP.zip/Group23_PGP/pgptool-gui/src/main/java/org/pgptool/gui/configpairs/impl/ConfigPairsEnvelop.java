
package org.pgptool.gui.configpairs.impl;

import java.util.HashMap;

public class ConfigPairsEnvelop extends HashMap<String, Object> {
	private static final long serialVersionUID = 7165377910943680166L;

}
