# PGP Tool
PGP Tool is a Java-based desktop GUI application for easy and regular PGP decryption/encryption of files on a file system.

It will be especially useful for those who tend to store sensitive information on their computer and sometimes sync this to google drive, drop box, etc.. And I don't want this information to be stored in un-encrypted state.

PGP software which is already exists doesn't seem to support this use case in a user-friendly way. It requires to perform  manual manual operations which is could be embarrising. Software supposed to automated things.

